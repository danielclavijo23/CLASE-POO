# Domotic Circuit Simulator — Advanced Version

## Requirements
- Python 3.8+
- PyQt5
- Pillow (for icons generation if reusing scripts)

## Install
```
pip install PyQt5 Pillow
```

## Run
```
python main.py
```

## Features added in this improved version
- Drag & drop movable components on a canvas (graphics scene)
- Connect two selected components with a connection line
- Properties panel to edit name, sensor value, bulb consumption
- Save and load projects (JSON)
- Visual feedback for active bulbs (opacity)
- Icons for components (in /icons)
- UML diagram included (uml.png) and PDF report

## Project structure
- logic/: domain classes
- data/: persistence
- ui/: advanced UI
- icons/: png icons
- uml.png: UML diagram image
- Workshop4_Advanced_Report.pdf: summary report
