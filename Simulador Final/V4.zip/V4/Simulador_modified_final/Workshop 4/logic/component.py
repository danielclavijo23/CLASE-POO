from abc import ABC, abstractmethod

class Component(ABC):
    def __init__(self, id_, name):
        self.id = id_
        self.name = name

    @abstractmethod
    def get_state(self):
        pass
