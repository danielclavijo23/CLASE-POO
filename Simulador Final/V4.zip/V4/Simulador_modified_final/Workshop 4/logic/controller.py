class Controller:
    def __init__(self):
        self.sensors = []
        self.actuators = []

    def add_sensor(self, sensor):
        self.sensors.append(sensor)

    def add_actuator(self, actuator):
        self.actuators.append(actuator)

    def process(self):
        # Example rule: if any sensor value > 0, activate all actuators
        active = any(s.read() > 0 for s in self.sensors)
        for a in self.actuators:
            if active:
                a.activate()
            else:
                a.deactivate()
