from .component import Component

class Actuator(Component):
    def __init__(self, id_, name):
        super().__init__(id_, name)
        self.state = False

    def activate(self):
        self.state = True

    def deactivate(self):
        self.state = False

    def get_state(self):
        return {"id": self.id, "type": "Actuator", "name": self.name, "state": self.state}
