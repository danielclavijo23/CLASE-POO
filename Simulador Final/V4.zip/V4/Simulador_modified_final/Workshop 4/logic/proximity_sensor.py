from .sensor import Sensor

class ProximitySensor(Sensor):
    def __init__(self, id_, name, range_cm=30, detection_mode="motion"):
        super().__init__(id_, name)
        self.range_cm = range_cm
        self.detection_mode = detection_mode
        self.object_detected = False
        self.sensor_type = "proximity"
    
    def set_value(self, v):
        super().set_value(v)
        self.object_detected = v > 0
    
    def is_object_detected(self):
        return self.object_detected
    
    def set_range(self, range_cm):
        if range_cm > 0:
            self.range_cm = range_cm
    
    def get_range(self):
        return self.range_cm
    
    def set_detection_mode(self, mode):
        if mode in ["motion", "presence", "distance"]:
            self.detection_mode = mode
    
    def get_detection_mode(self):
        return self.detection_mode
    
    def get_state(self):
        return {
            "id": self.id,
            "type": "ProximitySensor",
            "name": self.name,
            "value": self.value,
            "range_cm": self.range_cm,
            "detection_mode": self.detection_mode,
            "object_detected": self.object_detected
        }
