from .sensor import Sensor

class SmokeSensor(Sensor):
    def __init__(self, id_, name, threshold=30):
        super().__init__(id_, name)
        self.threshold = threshold
        self.smoke_detected = False
        self.sensor_type = "smoke"
    
    def set_value(self, v):
        super().set_value(v)
        self.smoke_detected = v >= self.threshold
    
    def is_smoke_detected(self):
        return self.smoke_detected
    
    def set_threshold(self, threshold):
        if threshold >= 0:
            self.threshold = threshold
    
    def get_threshold(self):
        return self.threshold
    
    def get_state(self):
        return {
            "id": self.id,
            "type": "SmokeSensor",
            "name": self.name,
            "value": self.value,
            "threshold": self.threshold,
            "smoke_detected": self.smoke_detected
        }
