from .actuator import Actuator

class Bulb(Actuator):
    def __init__(self, id_, name, consumption=5):
        super().__init__(id_, name)
        self.consumption = consumption

    def get_state(self):
        return {
            "id": self.id,
            "type": "Bulb",
            "name": self.name,
            "state": self.state,
            "consumption": self.consumption if self.state else 0
        }
