from .actuator import Actuator

class Switch(Actuator):
    def toggle(self):
        self.state = not self.state

    def get_state(self):
        return {"id": self.id, "type": "Switch", "name": self.name, "state": self.state}
