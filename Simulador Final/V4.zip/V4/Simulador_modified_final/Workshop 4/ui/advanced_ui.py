import sys, uuid, json
from PyQt5.QtWidgets import (
    QApplication, QWidget, QPushButton, QVBoxLayout, 
    QLabel, QHBoxLayout, QListWidget, QListWidgetItem,
    QGraphicsView, QGraphicsScene, QGraphicsPixmapItem,
    QGraphicsItem, QGraphicsLineItem, QFormLayout, QSpinBox,
    QGroupBox, QLineEdit, QFileDialog, QMessageBox, QScrollArea
)
from PyQt5.QtGui import QPixmap, QIcon, QPen, QColor, QBrush, QFont
from PyQt5.QtCore import Qt, QPointF

class NodeItem(QGraphicsPixmapItem):
    def __init__(self, comp_obj, pixmap):
        super().__init__(pixmap)
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable)
        self.comp = comp_obj
        self.ui_ref = None

    def contextMenuEvent(self, event):
        try:
            if self.ui_ref and hasattr(self.ui_ref, 'show_component_menu'):
                self.ui_ref.show_component_menu(self, event)
        except Exception:
            pass

class ConnectionLine(QGraphicsLineItem):
    def __init__(self, start_item, end_item):
        super().__init__()
        self.setZValue(-1)
        self.start = start_item
        self.end = end_item
        self.update_pos()
        self.update_color()

    def update_pos(self):
        p1 = self.start.scenePos() + QPointF(self.start.pixmap().width()/2, self.start.pixmap().height()/2)
        p2 = self.end.scenePos() + QPointF(self.end.pixmap().width()/2, self.end.pixmap().height()/2)
        self.setLine(p1.x(), p1.y(), p2.x(), p2.y())

    def update_color(self):
        if self.start.comp.get('state', False) or self.end.comp.get('state', False):
            color = QColor(0, 200, 0)
            width = 4
        else:
            color = QColor(180, 180, 180)
            width = 2
        pen = QPen(color, width)
        self.setPen(pen)

class UserInterface(QWidget):
    def __init__(self, simulator, data_manager, icon_paths):
        super().__init__()
        self.simulator = simulator
        self.data_manager = data_manager
        self.icon_paths = icon_paths

        self.setWindowTitle("Domotic Circuit Simulator — Advanced")
        self.setGeometry(100,100,1400,800)

        main_layout = QHBoxLayout()
        left_panel = QVBoxLayout()
        left_panel.addWidget(QLabel("<b>Components</b>"))

        self.component_list = QListWidget()
        self.component_list.addItem(QListWidgetItem(QIcon(icon_paths['bulb']), "Bulb"))
        self.component_list.addItem(QListWidgetItem(QIcon(icon_paths['switch']), "Switch"))
        self.component_list.addItem(QListWidgetItem(QIcon(icon_paths.get('alarm', icon_paths['bulb'])), "Alarm"))
        self.component_list.addItem(QListWidgetItem(QIcon(icon_paths.get('smokesensor', icon_paths['bulb'])), "SmokeSensor"))
        self.component_list.addItem(QListWidgetItem(QIcon(icon_paths.get('proximitysensor', icon_paths['bulb'])), "ProximitySensor"))
        left_panel.addWidget(self.component_list)

        btn_add = QPushButton("Add to Canvas")
        btn_add.clicked.connect(self.add_component_to_canvas)
        left_panel.addWidget(btn_add)

        btn_connect = QPushButton("Connect Selected")
        btn_connect.clicked.connect(self.connect_selected)
        left_panel.addWidget(btn_connect)

        btn_simulate = QPushButton("Simulate")
        btn_simulate.clicked.connect(self.simulate)
        left_panel.addWidget(btn_simulate)

        btn_save = QPushButton("Save Project")
        btn_save.clicked.connect(self.save_project)
        left_panel.addWidget(btn_save)

        btn_load = QPushButton("Load Project")
        btn_load.clicked.connect(self.load_project)
        left_panel.addWidget(btn_load)

        left_panel.addStretch()

        # Canvas
        self.scene = QGraphicsScene()
        self.canvas = QGraphicsView(self.scene)
        self.canvas.setRenderHints(self.canvas.renderHints())

        # Right panel - properties, switches control, statistics and log
        right_panel = QVBoxLayout()
        right_panel.addWidget(QLabel("<b>Properties</b>"))
        self.prop_group = QGroupBox()
        self.prop_layout = QFormLayout()
        self.prop_group.setLayout(self.prop_layout)
        right_panel.addWidget(self.prop_group)

        right_panel.addWidget(QLabel("<b>Quick Switch Control</b>"))
        self.switches_panel = QVBoxLayout()
        switches_scroll = QGroupBox()
        switches_scroll.setLayout(self.switches_panel)
        right_panel.addWidget(switches_scroll)

        right_panel.addWidget(QLabel("<b>Statistics</b>"))
        self.stats_label = QLabel("No components")
        self.stats_label.setWordWrap(True)
        stats_font = QFont()
        stats_font.setPointSize(9)
        self.stats_label.setFont(stats_font)
        right_panel.addWidget(self.stats_label)

        right_panel.addWidget(QLabel("<b>Log</b>"))
        self.log_label = QLabel("Ready")
        self.log_label.setWordWrap(True)
        right_panel.addWidget(self.log_label)

        main_layout.addLayout(left_panel,2)
        main_layout.addWidget(self.canvas,6)
        main_layout.addLayout(right_panel,2)
        self.setLayout(main_layout)

        # internal
        self.nodes = []  # NodeItem list
        self.connections = []  # ConnectionLine list

        # selection handling
        self.scene.selectionChanged.connect(self.on_selection_changed)

    def add_component_to_canvas(self):
        item = self.component_list.currentItem()
        if not item:
            return
        kind = item.text()
        # create domain object
        cid = str(uuid.uuid4())[:8]
        if kind == "Bulb":
            comp = {"id": cid, "type":"Bulb", "name": f"Bulb_{cid}", "state": False, "consumption":5}
        elif kind == "Switch":
            comp = {"id": cid, "type":"Switch", "name": f"Switch_{cid}", "state": False}
        elif kind == "Alarm":
            comp = {"id": cid, "type":"Alarm", "name": f"Alarm_{cid}", "state": False, "active": False, "volume": 80}
        elif kind == "SmokeSensor":
            comp = {"id": cid, "type":"SmokeSensor", "name": f"SmokeSensor_{cid}", "value": 0, "threshold": 30, "smoke_detected": False}
        elif kind == "ProximitySensor":
            comp = {"id": cid, "type":"ProximitySensor", "name": f"ProximitySensor_{cid}", "value": 0, "range_cm": 30, "detection_mode": "motion", "object_detected": False}
        else:
            comp = {"id": cid, "type":"Switch", "name": f"Switch_{cid}", "state": False}

        # pixmap
        icon_key = kind.lower()
        if icon_key == "smokesensor":
            icon_key = "smokesensor"
        elif icon_key == "alarm":
            icon_key = "alarm"
        elif icon_key == "proximitysensor":
            icon_key = "proximitysensor"
        pix = QPixmap(self.icon_paths.get(icon_key, self.icon_paths['bulb'])).scaled(80,80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        node = NodeItem(comp, pix)
        node.setPos(50 + len(self.nodes)*90, 50)
        self.scene.addItem(node)
        self.nodes.append(node)
        node.ui_ref = self
        # register in simulator logic (create actual logic objects)
        # The simulator expects real class instances; we store mapping in node.comp_obj later during save/load or by factory
        self.log(f"Added {comp['type']} {comp['name']}")
        self.on_selection_changed()

    def connect_selected(self):
        selected = [it for it in self.scene.selectedItems() if isinstance(it, NodeItem)]
        if len(selected) == 2:
            a,b = selected
            conn = ConnectionLine(a,b)
            self.connections.append(conn)
            self.scene.addItem(conn)
            self.log(f"Connected {a.comp['name']} -> {b.comp['name']}")
        else:
            QMessageBox.information(self, "Connect", "Select exactly two components to connect")

    def simulate(self):
        # Simulation behavior
        any_active = False
        smoke_detected = False
        proximity_detected = False
        
        # Check for sensors
        for node in self.nodes:
            if node.comp['type']=="SmokeSensor":
                node.comp['smoke_detected'] = node.comp.get('value',0) >= node.comp.get('threshold',30)
                if node.comp['smoke_detected']:
                    smoke_detected = True
            elif node.comp['type']=="ProximitySensor":
                node.comp['object_detected'] = node.comp.get('value',0) > 0
                if node.comp['object_detected']:
                    proximity_detected = True
            elif node.comp['type']=="Switch" and node.comp.get('state',False):
                any_active = True
        
        # Activate alarms if smoke detected
        for node in self.nodes:
            if node.comp['type']=="Alarm":
                if smoke_detected or proximity_detected:
                    node.comp['state'] = True
                    node.comp['active'] = True
                    node.setOpacity(1.0)
                else:
                    node.comp['state'] = False
                    node.comp['active'] = False
                    node.setOpacity(0.4)
        
        # Activate bulbs based on switches or proximity
        for node in self.nodes:
            if node.comp['type']=="Bulb":
                node.comp['state'] = any_active or proximity_detected
                if node.comp['state']:
                    node.setOpacity(1.0)
                else:
                    node.setOpacity(0.4)
        
        self.log("Simulation step executed")
        # update connection lines positions
        for c in self.connections:
            c.update_pos()
        # refresh properties panel and update visuals
        self.update_connection_colors()
        self.on_selection_changed()

    def on_selection_changed(self):
        selected = [it for it in self.scene.selectedItems() if isinstance(it, NodeItem)]
        # rebuild properties panel
        for i in reversed(range(self.prop_layout.count())):
            self.prop_layout.removeRow(i)
        if selected:
            node = selected[0]
            comp = node.comp
            # name
            name_edit = QLineEdit(comp.get('name',''))
            def on_name_change(): 
                comp['name'] = name_edit.text()
                node.comp = comp
            name_edit.editingFinished.connect(on_name_change)
            self.prop_layout.addRow("Name:", name_edit)
            
            if comp['type']=="Switch":
                toggle_btn = QPushButton(f"Toggle (Current: {comp.get('state', False)})")
                def on_toggle():
                    comp['state'] = not comp.get('state', False)
                    toggle_btn.setText(f"Toggle (Current: {comp['state']})")
                    node.comp = comp
                    self.update_connection_colors()
                    self.on_selection_changed()
                toggle_btn.clicked.connect(on_toggle)
                self.prop_layout.addRow("State:", toggle_btn)
                
            if comp['type']=="Bulb":
                cons = QSpinBox(); cons.setRange(1,1000); cons.setValue(comp.get('consumption',5))
                cons.valueChanged.connect(lambda v: comp.update({'consumption':v}))
                self.prop_layout.addRow("Consumption:", cons)
                
            if comp['type']=="Alarm":
                vol = QSpinBox(); vol.setRange(0,100); vol.setValue(comp.get('volume',80))
                vol.valueChanged.connect(lambda v: comp.update({'volume':v}))
                self.prop_layout.addRow("Volume:", vol)
                
            if comp['type']=="SmokeSensor":
                thresh = QSpinBox(); thresh.setRange(0,100); thresh.setValue(comp.get('threshold',30))
                thresh.valueChanged.connect(lambda v: comp.update({'threshold':v}))
                self.prop_layout.addRow("Threshold:", thresh)
                val = QSpinBox(); val.setRange(0,100); val.setValue(comp.get('value',0))
                val.valueChanged.connect(lambda v: comp.update({'value':v}))
                self.prop_layout.addRow("Smoke Value:", val)
                
            if comp['type']=="ProximitySensor":
                rng = QSpinBox(); rng.setRange(1,500); rng.setValue(comp.get('range_cm',30))
                rng.valueChanged.connect(lambda v: comp.update({'range_cm':v}))
                self.prop_layout.addRow("Range (cm):", rng)
                val = QSpinBox(); val.setRange(0,100); val.setValue(comp.get('value',0))
                val.valueChanged.connect(lambda v: comp.update({'value':v}))
                self.prop_layout.addRow("Distance Value:", val)
            
            delete_btn = QPushButton("🗑 Delete Component")
            delete_btn.clicked.connect(lambda: self.delete_node(node))
            self.prop_layout.addRow(delete_btn)
        
        self.update_switches_panel()
        self.update_statistics()

    def update_switches_panel(self):
        for i in reversed(range(self.switches_panel.count())):
            widget = self.switches_panel.itemAt(i).widget()
            if widget:
                self.switches_panel.removeWidget(widget)
                widget.deleteLater()
        
        switches = [n for n in self.nodes if n.comp['type'] == "Switch"]
        if not switches:
            self.switches_panel.addWidget(QLabel("No switches"))
        else:
            for node in switches:
                comp = node.comp
                btn = QPushButton(f"{comp['name']}: {comp.get('state', False)}")
                btn.setStyleSheet(f"background-color: {'#90EE90' if comp.get('state', False) else '#FFB6C6'}")
                def make_toggle(n):
                    def on_click():
                        n.comp['state'] = not n.comp.get('state', False)
                        self.update_connection_colors()
                        self.on_selection_changed()
                    return on_click
                btn.clicked.connect(make_toggle(node))
                self.switches_panel.addWidget(btn)

    def update_statistics(self):
        bulbs = [n for n in self.nodes if n.comp['type'] == "Bulb"]
        switches = [n for n in self.nodes if n.comp['type'] == "Switch"]
        alarms = [n for n in self.nodes if n.comp['type'] == "Alarm"]
        sensors = [n for n in self.nodes if n.comp['type'] in ["SmokeSensor", "ProximitySensor"]]
        
        active_bulbs = sum(1 for b in bulbs if b.comp.get('state', False))
        active_switches = sum(1 for s in switches if s.comp.get('state', False))
        active_alarms = sum(1 for a in alarms if a.comp.get('state', False))
        
        total_consumption = sum(b.comp.get('consumption', 5) for b in bulbs if b.comp.get('state', False))
        
        stats_text = f"""
Total Components: {len(self.nodes)}
Bulbs: {len(bulbs)} (Active: {active_bulbs})
Switches: {len(switches)} (Active: {active_switches})
Alarms: {len(alarms)} (Active: {active_alarms})
Sensors: {len(sensors)}
Total Energy: {total_consumption}W
        """
        self.stats_label.setText(stats_text.strip())

    def update_connection_colors(self):
        for conn in self.connections:
            conn.update_color()

    def show_component_menu(self, node, event):
        """Show context menu for a node (delete, rotate, properties)."""
        from PyQt5.QtWidgets import QMenu
        menu = QMenu(self)
        delete_action = menu.addAction("🗑 Delete")
        rotate_action = menu.addAction("🔄 Rotate")
        props_action = menu.addAction("⚙ Properties")
        selected = menu.exec_(event.globalPos())
        if selected == delete_action:
            self.delete_node(node)
        elif selected == rotate_action:
            self.rotate_node(node)
        elif selected == props_action:
            self.open_properties(node)

    def delete_node(self, node):
        # remove related connections
        try:
            to_remove = [c for c in self.connections if c.start == node or c.end == node]
            for c in to_remove:
                if c in self.connections:
                    try:
                        self.scene.removeItem(c)
                    except Exception:
                        pass
                    self.connections.remove(c)
            # remove node
            if node in self.nodes:
                try:
                    self.scene.removeItem(node)
                except Exception:
                    pass
                self.nodes.remove(node)
            self.log(f"Deleted component {node.comp.get('name')}")
            self.on_selection_changed()
        except Exception as e:
            self.log(f"Error deleting node: {e}")

    def rotate_node(self, node):
        try:
            node.setRotation((node.rotation() + 90) % 360)
            self.update_connections()
            self.log(f"Rotated {node.comp.get('name')}")
        except Exception as e:
            self.log(f"Rotate error: {e}")

    def open_properties(self, node):
        # populate properties panel with node.comp data and show it
        try:
            self.component_list.clearSelection()
        except Exception:
            pass
        # reuse existing properties UI if present
        try:
            self.prop_widget.show() 
            # set the prop values if form exists (best-effort)
            # existing code already builds properties when selection changes
        except Exception:
            pass



    def save_project(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save Project", "", "JSON Files (*.json)")
        if not path:
            return
        proj = {"components": [], "connections":[]}
        for node in self.nodes:
            proj["components"].append(node.comp)
        for c in self.connections:
            proj["connections"].append({"start": c.start.comp['id'], "end": c.end.comp['id']})
        with open(path, "w") as f:
            json.dump(proj, f, indent=4)
        self.log(f"Project saved to {path}")

    def load_project(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load Project", "", "JSON Files (*.json)")
        if not path:
            return
        with open(path, "r") as f:
            proj = json.load(f)
        # clear scene
        for item in self.scene.items():
            self.scene.removeItem(item)
        self.nodes = []
        self.connections = []
        # create nodes
        x=50; y=50
        for c in proj.get("components", []):
            kind = c.get("type","Bulb")
            kind_lower = kind.lower()
            if kind_lower == "smokesensor":
                icon_key = "smokesensor"
            elif kind_lower == "alarm":
                icon_key = "alarm"
            elif kind_lower == "proximitysensor":
                icon_key = "proximitysensor"
            else:
                icon_key = kind_lower
            pix = QPixmap(self.icon_paths.get(icon_key, self.icon_paths['bulb'])).scaled(80,80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            node = NodeItem(c, pix)
            node.setPos(x,y)
            y += 100
            if y>500: y=50; x+=120
            self.scene.addItem(node)
            node.ui_ref = self
            self.nodes.append(node)
        # create connections by id mapping
        id_map = {n.comp['id']: n for n in self.nodes}
        for cc in proj.get("connections", []):
            s = id_map.get(cc['start']); e = id_map.get(cc['end'])
            if s and e:
                conn = ConnectionLine(s,e)
                self.connections.append(conn)
                self.scene.addItem(conn)
        self.log("Project loaded")

    def log(self, text):
        self.log_label.setText(text)
