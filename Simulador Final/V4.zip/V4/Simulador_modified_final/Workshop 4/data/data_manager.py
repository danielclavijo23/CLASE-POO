import json, os

class DataManager:
    def save(self, path, components):
        data = [c.get_state() for c in components]
        proj = {"components": data}
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(proj, f, indent=4)

    def load(self, path, factory):
        with open(path, "r") as f:
            proj = json.load(f)
        comps = []
        for c in proj.get("components", []):
            # factory should create objects from dict
            obj = factory(c)
            if obj:
                comps.append(obj)
        return comps
