from logic.bulb import Bulb
from logic.switch import Switch
from logic.controller import Controller
from logic.circuit_simulator import CircuitSimulator
from logic.alarm import Alarm
from logic.smoke_sensor import SmokeSensor
from logic.proximity_sensor import ProximitySensor
from data.data_manager import DataManager
from ui.advanced_ui import UserInterface
from PyQt5.QtWidgets import QApplication
import sys, os

if __name__ == '__main__':
    controller = Controller()
    sim = CircuitSimulator(controller)
    data = DataManager()
    # icons
    icon_dir = os.path.join(os.path.dirname(__file__),'icons')
    icon_paths = {'bulb': os.path.join(icon_dir,'bulb.png'),
                  'switch': os.path.join(icon_dir,'switch.png'),
                  'alarm': os.path.join(icon_dir,'alarm.png'),
                  'smokesensor': os.path.join(icon_dir,'smokesensor.png'),
                  'proximitysensor': os.path.join(icon_dir,'proximitysensor.png')}
    app = QApplication(sys.argv)
    ui = UserInterface(sim, data, icon_paths)
    ui.show()
    sys.exit(app.exec_())
