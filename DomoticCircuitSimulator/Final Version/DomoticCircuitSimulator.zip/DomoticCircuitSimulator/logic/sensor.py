from .component import Component
#father actuator class to use SOLID principles and polymorphism
class Sensor(Component):
    def __init__(self, id_, name):
        super().__init__(id_, name)
        self.value = 0

    def read(self):
        return self.value

    def set_value(self, v):
        self.value = v

    def get_state(self):
        return {"id": self.id, "type": "Sensor", "name": self.name, "value": self.value}
