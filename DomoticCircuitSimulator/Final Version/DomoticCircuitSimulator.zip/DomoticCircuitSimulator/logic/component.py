from abc import ABC, abstractmethod
#father actuator class to use SOLID principles and polymorphism
class Component(ABC):
    def __init__(self, id_, name):
        self.id = id_
        self.name = name

    @abstractmethod
    def get_state(self):
        pass
