#Simulation of circuit in logic
class CircuitSimulator:
    def __init__(self, controller):
        self.controller = controller
        self.components = {}

    def add_component(self, comp):
        self.components[comp.id] = comp

    def step(self):
        self.controller.process()

    def get_circuit_state(self):
        return [c.get_state() for c in self.components.values()]
