from .actuator import Actuator
#we create an alarm for de house
class Alarm(Actuator):
    def __init__(self, id_, name, volume=80):
        super().__init__(id_, name)
        self.volume = volume
        self.alarm_type = "alarm"
        self.active = False
    
    def trigger(self):
        self.state = True
        self.active = True
    
    def stop(self):
        self.state = False
        self.active = False
    
    def set_volume(self, vol):
        if 0 <= vol <= 100:
            self.volume = vol
    
    def get_volume(self):
        return self.volume
    
    def is_active(self):
        return self.active
    
    def get_state(self):
        return {
            "id": self.id,
            "type": "Alarm",
            "name": self.name,
            "state": self.state,
            "active": self.active,
            "volume": self.volume
        }
