class Component:
    def __init__(self, comp_id, comp_type):
        self.id = comp_id
        self.type = comp_type
        self.state = False

    def toggle(self):
        if self.type == "switch":
            self.state = not self.state

class Switch(Component):
    def __init__(self, comp_id):
        super().__init__(comp_id, "switch")

class Light(Component):
    def __init__(self, comp_id):
        super().__init__(comp_id, "light")
