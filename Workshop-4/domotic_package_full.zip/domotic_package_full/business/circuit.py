from .components import Switch, Light

class Circuit:
    def __init__(self):
        self.components = {}
        self.connections = []

    def add_component(self, component):
        self.components[component.id] = component

    def connect(self, a, b):
        if a in self.components and b in self.components:
            self.connections.append((a, b))

    def simulate(self):
        for a, b in self.connections:
            A = self.components[a]
            B = self.components[b]
            if A.type == "switch" and B.type == "light":
                B.state = A.state
            elif B.type == "switch" and A.type == "light":
                A.state = B.state
