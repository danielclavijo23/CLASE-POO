import json

class Storage:
    @staticmethod
    def save(circuit, filename):
        data = {
            "components": [
                {"id": c.id, "type": c.type, "state": c.state}
                for c in circuit.components.values()
            ],
            "connections": circuit.connections
        }
        with open(filename, "w") as f:
            json.dump(data, f, indent=4)

    @staticmethod
    def load(filename, circuit_class, component_map):
        with open(filename, "r") as f:
            data = json.load(f)

        circuit = circuit_class()

        for c in data.get("components", []):
            cls = component_map.get(c["type"])
            comp = cls(c["id"])
            comp.state = c["state"]
            circuit.add_component(comp)

        for conn in data.get("connections", []):
            circuit.connect(*conn)

        return circuit
