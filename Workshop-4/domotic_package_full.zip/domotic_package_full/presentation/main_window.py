from PyQt5.QtWidgets import QWidget, QPushButton, QListWidget, QVBoxLayout, QHBoxLayout, QFileDialog
from business.circuit import Circuit
from business.components import Switch, Light
from data.storage import Storage

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Domotic Circuit Simulator")

        self.circuit = Circuit()
        self.list_components = QListWidget()

        self.btn_add_switch = QPushButton("Add Switch")
        self.btn_add_light = QPushButton("Add Light")
        self.btn_connect = QPushButton("Connect")
        self.btn_simulate = QPushButton("Simulate")
        self.btn_save = QPushButton("Save")
        self.btn_load = QPushButton("Load")

        layout = QVBoxLayout()
        layout.addWidget(self.list_components)

        btns = QHBoxLayout()
        btns.addWidget(self.btn_add_switch)
        btns.addWidget(self.btn_add_light)
        layout.addLayout(btns)

        layout.addWidget(self.btn_connect)
        layout.addWidget(self.btn_simulate)
        layout.addWidget(self.btn_save)
        layout.addWidget(self.btn_load)

        self.setLayout(layout)

        self.btn_add_switch.clicked.connect(self.add_switch)
        self.btn_add_light.clicked.connect(self.add_light)
        self.btn_connect.clicked.connect(self.connect)
        self.btn_simulate.clicked.connect(self.simulate)
        self.btn_save.clicked.connect(self.save)
        self.btn_load.clicked.connect(self.load)

    def add_switch(self):
        comp = Switch(f"sw{len(self.circuit.components)}")
        self.circuit.add_component(comp)
        self.update_list()

    def add_light(self):
        comp = Light(f"lt{len(self.circuit.components)}")
        self.circuit.add_component(comp)
        self.update_list()

    def connect(self):
        ids = list(self.circuit.components.keys())
        if len(ids) >= 2:
            self.circuit.connect(ids[0], ids[1])
        self.update_list()

    def simulate(self):
        self.circuit.simulate()
        self.update_list()

    def save(self):
        file, _ = QFileDialog.getSaveFileName(self, "Save Circuit", "", "JSON (*.json)")
        if file:
            Storage.save(self.circuit, file)

    def load(self):
        file, _ = QFileDialog.getOpenFileName(self, "Load Circuit", "", "JSON (*.json)")
        if file:
            self.circuit = Storage.load(file, Circuit, {"switch": Switch, "light": Light})
        self.update_list()

    def update_list(self):
        self.list_components.clear()
        for c in self.circuit.components.values():
            self.list_components.addItem(f"{c.id} | {c.type} | state={c.state}")
